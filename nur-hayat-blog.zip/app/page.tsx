import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Code, Database, GraduationCap, Layers, Lightbulb } from "lucide-react"
import Link from "next/link"

export default function Home() {
  return (
    <div className="container py-10 space-y-8">
      <section className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Merhaba, Ben Nur Hayat Yavuz</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          Bilgisayar Mühendisi olarak yazılım geliştirme, veri analizi ve sistem yönetimi alanlarında güçlü bir teknik
          bilgiye sahibim. Özellikle Java Backend geliştirme konusunda deneyimliyim.
        </p>
        <div className="flex gap-4 pt-4">
          <Button asChild>
            <Link href="/projeler">
              Projelerim <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/iletisim">İletişime Geç</Link>
          </Button>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-8">
        <Card>
          <CardHeader className="space-y-1">
            <div className="flex items-center gap-2">
              <Code size={20} className="text-primary" />
              <CardTitle>Backend Geliştirme</CardTitle>
            </div>
            <CardDescription>Java ve Spring Boot ile güçlü backend sistemleri</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <Badge>Java</Badge>
              <Badge>Spring Boot</Badge>
              <Badge>REST API</Badge>
              <Badge>PostgreSQL</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="space-y-1">
            <div className="flex items-center gap-2">
              <Layers size={20} className="text-primary" />
              <CardTitle>Frontend Geliştirme</CardTitle>
            </div>
            <CardDescription>Kullanıcı dostu arayüzler tasarlama ve geliştirme</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <Badge>HTML</Badge>
              <Badge>CSS</Badge>
              <Badge>Angular</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="space-y-1">
            <div className="flex items-center gap-2">
              <Lightbulb size={20} className="text-primary" />
              <CardTitle>Veri Analizi & Yapay Zeka</CardTitle>
            </div>
            <CardDescription>Python ve TensorFlow ile veri analizi ve yapay zeka çözümleri</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <Badge>Python</Badge>
              <Badge>TensorFlow</Badge>
              <Badge>Makine Öğrenmesi</Badge>
            </div>
          </CardContent>
        </Card>
      </section>

      <section className="py-8">
        <h2 className="text-2xl font-bold mb-6">Öne Çıkan Projeler</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Alzheimer Tespiti</CardTitle>
              <CardDescription>1D ve 2D sinyaller ile alzheimer tespiti</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Python ve Makine Öğrenmesi teknikleri kullanarak 1D ve 2D sinyallerden Alzheimer hastalığını tespit eden
                bir sistem geliştirdim.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">Python</Badge>
                <Badge variant="outline">Makine Öğrenmesi</Badge>
                <Badge variant="outline">Sinyal İşleme</Badge>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Etkinlik Takip Uygulaması</CardTitle>
              <CardDescription>Tam kapsamlı etkinlik yönetim sistemi</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Java, Spring Boot, Angular ve PostgreSQL kullanarak etkinliklerin oluşturulması, düzenlenmesi ve takip
                edilmesini sağlayan bir uygulama geliştirdim.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">Java</Badge>
                <Badge variant="outline">Spring Boot</Badge>
                <Badge variant="outline">Angular</Badge>
                <Badge variant="outline">PostgreSQL</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="mt-6 text-center">
          <Button variant="outline" asChild>
            <Link href="/projeler">
              Tüm Projeleri Gör <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      <section className="py-8">
        <h2 className="text-2xl font-bold mb-6">Eğitim & Deneyim</h2>
        <div className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-start gap-4">
              <div className="mt-1 bg-primary/10 p-2 rounded-full">
                <GraduationCap className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>Bartın Üniversitesi</CardTitle>
                <CardDescription>Bilgisayar Mühendisliği (2019-2024)</CardDescription>
              </div>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-start gap-4">
              <div className="mt-1 bg-primary/10 p-2 rounded-full">
                <Database className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>Ankaref (Ankara)</CardTitle>
                <CardDescription>Java Backend Developer Stajyeri</CardDescription>
                <p className="text-sm text-muted-foreground mt-2">
                  Spring Boot, PostgreSQL ve REST API geliştirme süreçlerinde yer aldım.
                </p>
              </div>
            </CardHeader>
          </Card>
        </div>
      </section>
    </div>
  )
}
