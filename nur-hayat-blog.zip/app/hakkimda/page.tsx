import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, GraduationCap, Languages, User } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="container py-10 space-y-8">
      <section className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Hakkımda</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          Yazılım geliştirme, veri analizi ve sistem yönetimi alanlarında güçlü bir teknik bilgiye sahibim.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 py-6">
        <Card>
          <CardHeader className="space-y-1">
            <div className="flex items-center gap-2">
              <User size={20} className="text-primary" />
              <CardTitle>Profil</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              Bilgisayar Mühendisliği alanında lisans eğitimimi tamamladım. Yazılım geliştirme, veri analizi ve sistem
              yönetimi alanlarında güçlü bir teknik bilgiye sahibim. Özellikle Java Backend geliştirme konusunda
              deneyimliyim ve Spring Boot, REST API ve veritabanı yönetimi üzerine çalışıyorum.
            </p>
            <p>
              Staj sürecimde Angular & Spring Boot kullanarak projeler geliştirdim. Problem çözme yeteneğim ve analitik
              düşünme becerim sayesinde farklı projelerde etkin çözümler üretebiliyorum.
            </p>
            <p>Teknolojideki yenilikleri takip ederek kendimi sürekli geliştirmeyi hedefliyorum.</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="space-y-1">
            <div className="flex items-center gap-2">
              <GraduationCap size={20} className="text-primary" />
              <CardTitle>Eğitim</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-medium">Bartın Üniversitesi</h3>
              <p className="text-sm text-muted-foreground">Bilgisayar Mühendisliği (2019-2024)</p>
              <p>
                Bilgisayar Mühendisliği bölümünde algoritma tasarımı, veri yapıları, yazılım mühendisliği, veritabanı
                sistemleri ve yapay zeka gibi alanlarda kapsamlı eğitim aldım.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="space-y-1">
            <div className="flex items-center gap-2">
              <Languages size={20} className="text-primary" />
              <CardTitle>Dil Becerileri</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <h3 className="font-medium">İngilizce</h3>
                <Badge>B1-B2</Badge>
              </div>
              <p className="text-sm text-muted-foreground">Konuşma: B1 | Okuma/Yazma: B2</p>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <h3 className="font-medium">Almanca</h3>
                <Badge>A1-A2</Badge>
              </div>
              <p className="text-sm text-muted-foreground">Konuşma: A1 | Okuma/Yazma: A2</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="space-y-1">
            <div className="flex items-center gap-2">
              <BookOpen size={20} className="text-primary" />
              <CardTitle>Sertifikalar</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex justify-between">
                <span>Python Tutorial</span>
                <span className="text-sm text-muted-foreground">BTK Akademi (2023)</span>
              </li>
              <li className="flex justify-between">
                <span>Java Developer Bootcamp</span>
                <span className="text-sm text-muted-foreground">Udemy (2024)</span>
              </li>
              <li className="flex justify-between">
                <span>Spring Boot Tutorial</span>
                <span className="text-sm text-muted-foreground">Udemy (2025)</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
