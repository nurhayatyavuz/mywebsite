import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileCode, Layers, Lightbulb, Server } from "lucide-react"

const backendSkills = [
  { name: "Java", level: 85 },
  { name: "Spring Boot", level: 80 },
  { name: "REST API", level: 75 },
  { name: "PostgreSQL", level: 70 },
  { name: "Veritabanı Tasarımı", level: 65 },
]

const frontendSkills = [
  { name: "HTML", level: 80 },
  { name: "CSS", level: 75 },
  { name: "Angular", level: 60 },
  { name: "Responsive Design", level: 65 },
]

const aiSkills = [
  { name: "Python", level: 75 },
  { name: "TensorFlow", level: 65 },
  { name: "Makine Öğrenmesi", level: 60 },
  { name: "Veri Analizi", level: 70 },
]

const otherSkills = [
  { name: "Git & GitHub", level: 75 },
  { name: "Agile/Scrum", level: 65 },
  { name: "Problem Çözme", level: 85 },
  { name: "Analitik Düşünme", level: 80 },
]

export default function SkillsPage() {
  return (
    <div className="container py-10 space-y-8">
      <section className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Yeteneklerim</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          Teknik ve profesyonel becerilerim hakkında detaylı bilgiler.
        </p>
      </section>

      <Tabs defaultValue="backend" className="w-full">
        <TabsList className="grid grid-cols-4 mb-8">
          <TabsTrigger value="backend">Backend</TabsTrigger>
          <TabsTrigger value="frontend">Frontend</TabsTrigger>
          <TabsTrigger value="ai">Yapay Zeka</TabsTrigger>
          <TabsTrigger value="other">Diğer</TabsTrigger>
        </TabsList>

        <TabsContent value="backend">
          <Card>
            <CardHeader className="space-y-1">
              <div className="flex items-center gap-2">
                <Server size={20} className="text-primary" />
                <CardTitle>Backend Geliştirme</CardTitle>
              </div>
              <CardDescription>Java ve Spring Boot ile güçlü backend sistemleri geliştirme</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {backendSkills.map((skill) => (
                  <div key={skill.name} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-muted-foreground">{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="frontend">
          <Card>
            <CardHeader className="space-y-1">
              <div className="flex items-center gap-2">
                <Layers size={20} className="text-primary" />
                <CardTitle>Frontend Geliştirme</CardTitle>
              </div>
              <CardDescription>Kullanıcı dostu arayüzler tasarlama ve geliştirme</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {frontendSkills.map((skill) => (
                  <div key={skill.name} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-muted-foreground">{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai">
          <Card>
            <CardHeader className="space-y-1">
              <div className="flex items-center gap-2">
                <Lightbulb size={20} className="text-primary" />
                <CardTitle>Veri Analizi & Yapay Zeka</CardTitle>
              </div>
              <CardDescription>Python ve TensorFlow ile veri analizi ve yapay zeka çözümleri</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {aiSkills.map((skill) => (
                  <div key={skill.name} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-muted-foreground">{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="other">
          <Card>
            <CardHeader className="space-y-1">
              <div className="flex items-center gap-2">
                <FileCode size={20} className="text-primary" />
                <CardTitle>Diğer Beceriler</CardTitle>
              </div>
              <CardDescription>Profesyonel ve teknik diğer becerilerim</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {otherSkills.map((skill) => (
                  <div key={skill.name} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-muted-foreground">{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
