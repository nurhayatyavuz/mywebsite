import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Github } from "lucide-react"
import Link from "next/link"

const projects = [
  {
    id: 1,
    title: "Alzheimer Tespiti",
    description: "1D ve 2D sinyaller ile alzheimer tespiti",
    longDescription:
      "Python ve Makine Öğrenmesi teknikleri kullanarak 1D ve 2D sinyallerden Alzheimer hastalığını tespit eden bir sistem geliştirdim. Bu projede, EEG sinyallerini ve beyin görüntülerini analiz ederek hastalığın erken teşhisine yardımcı olan bir model oluşturdum.",
    technologies: ["Python", "Makine Öğrenmesi", "TensorFlow", "Sinyal İşleme", "Veri Analizi"],
    githubUrl: "https://github.com/nurhayatyavuz/alzheimer-detection",
    demoUrl: "#",
  },
  {
    id: 2,
    title: "Etkinlik Takip Uygulaması",
    description: "Etkinliklerin oluşturulması ve takip edilmesi için web uygulaması",
    longDescription:
      "Java, Spring Boot, Angular ve PostgreSQL kullanarak etkinliklerin oluşturulması, düzenlenmesi ve takip edilmesini sağlayan kapsamlı bir web uygulaması geliştirdim. Kullanıcılar etkinlik oluşturabilir, katılımcı ekleyebilir ve etkinlik detaylarını güncelleyebilir.",
    technologies: ["Java", "Spring Boot", "Angular", "PostgreSQL", "REST API", "JWT Authentication"],
    githubUrl: "https://github.com/nurhayatyavuz/event-tracker",
    demoUrl: "#",
  },
  {
    id: 3,
    title: "Masaüstü Uygulaması",
    description: "Python ile geliştirilmiş masaüstü uygulaması",
    longDescription:
      "Python ve PyQt5 kullanarak geliştirdiğim bu masaüstü uygulaması, kullanıcıların günlük görevlerini organize etmelerine ve takip etmelerine yardımcı oluyor. Uygulama, görev ekleme, düzenleme, silme ve tamamlama işlevlerini içeriyor.",
    technologies: ["Python", "PyQt5", "SQLite", "UI/UX Design"],
    githubUrl: "https://github.com/nurhayatyavuz/desktop-app",
    demoUrl: "#",
  },
  {
    id: 4,
    title: "Sosyal Sorumluluk Web Sitesi",
    description: "Topluluk etkinlikleri ve sosyal sorumluluk projeleri için web sitesi",
    longDescription:
      "HTML, CSS ve JavaScript kullanarak geliştirdiğim bu web sitesi, sosyal sorumluluk projelerinin duyurulması ve gönüllülerin bu projelere katılımını kolaylaştırmak amacıyla tasarlandı. Site, proje listeleme, gönüllü kayıt formu ve etkinlik takvimi gibi özelliklere sahip.",
    technologies: ["HTML", "CSS", "JavaScript", "Responsive Design"],
    githubUrl: "https://github.com/nurhayatyavuz/social-responsibility",
    demoUrl: "#",
  },
]

export default function ProjectsPage() {
  return (
    <div className="container py-10 space-y-8">
      <section className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Projelerim</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          Geliştirdiğim projeler ve çalışmalarım hakkında detaylı bilgiler.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-8 py-6">
        {projects.map((project) => (
          <Card key={project.id} className="flex flex-col">
            <CardHeader>
              <CardTitle>{project.title}</CardTitle>
              <CardDescription>{project.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <p className="text-muted-foreground mb-4">{project.longDescription}</p>
              <div className="flex flex-wrap gap-2 mt-4">
                {project.technologies.map((tech) => (
                  <Badge key={tech} variant="outline">
                    {tech}
                  </Badge>
                ))}
              </div>
            </CardContent>
            <CardFooter className="flex gap-4">
              <Button variant="outline" size="sm" asChild>
                <Link href={project.githubUrl} target="_blank">
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                </Link>
              </Button>
              <Button size="sm" asChild>
                <Link href={project.demoUrl} target="_blank">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Demo
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </section>
    </div>
  )
}
