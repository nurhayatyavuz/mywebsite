import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowRight, Calendar } from "lucide-react"
import Link from "next/link"

const blogPosts = [
  {
    id: 1,
    title: "Spring Boot ile RESTful API Geliştirme",
    description: "Spring Boot kullanarak modern ve güvenli RESTful API'ler nasıl geliştirilir?",
    date: "15 Nisan 2024",
    category: "Backend",
    slug: "spring-boot-restful-api",
  },
  {
    id: 2,
    title: "Python ve TensorFlow ile Görüntü Sınıflandırma",
    description: "TensorFlow kullanarak basit bir görüntü sınıflandırma modeli nasıl oluşturulur?",
    date: "2 Mart 2024",
    category: "Yapay Zeka",
    slug: "python-tensorflow-goruntu-siniflandirma",
  },
  {
    id: 3,
    title: "Veritabanı Tasarımında En İyi Uygulamalar",
    description: "Veritabanı tasarımında dikkat edilmesi gereken önemli noktalar ve en iyi uygulamalar",
    date: "18 Şubat 2024",
    category: "Veritabanı",
    slug: "veritabani-tasariminda-en-iyi-uygulamalar",
  },
  {
    id: 4,
    title: "Angular ile Reactive Form Kullanımı",
    description: "Angular'da reactive formlar nasıl oluşturulur ve yönetilir?",
    date: "5 Ocak 2024",
    category: "Frontend",
    slug: "angular-reactive-form-kullanimi",
  },
]

export default function BlogPage() {
  return (
    <div className="container py-10 space-y-8">
      <section className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Blog</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          Yazılım geliştirme, veri bilimi ve teknoloji hakkında yazılarım.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 py-6">
        {blogPosts.map((post) => (
          <Card key={post.id} className="flex flex-col">
            <CardHeader>
              <div className="flex items-center justify-between mb-2">
                <Badge>{post.category}</Badge>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="mr-1 h-3 w-3" />
                  {post.date}
                </div>
              </div>
              <CardTitle>{post.title}</CardTitle>
              <CardDescription>{post.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <p className="text-muted-foreground">
                Bu yazıda, {post.category.toLowerCase()} alanında detaylı bilgiler ve pratik örnekler paylaşıyorum.
                Konuyla ilgili deneyimlerimi ve öğrendiklerimi sizlerle paylaşmaktan mutluluk duyuyorum.
              </p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" asChild>
                <Link href={`/blog/${post.slug}`}>
                  Devamını Oku <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </section>
    </div>
  )
}
