"use client"

import { usePathname } from "next/navigation"
import Link from "next/link"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar"
import { ModeToggle } from "@/components/mode-toggle"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { BookOpen, Code, FileCode, Github, Home, Linkedin, Mail, Phone, User } from "lucide-react"

export function AppSidebar() {
  const pathname = usePathname()

  const isActive = (path: string) => {
    return pathname === path
  }

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex flex-col items-center space-y-2 py-2">
          <Avatar className="h-20 w-20">
            <AvatarImage src="/images/profile-photo.png" alt="Nur Hayat Yavuz" />
            <AvatarFallback>NY</AvatarFallback>
          </Avatar>
          <div className="text-center space-y-1">
            <h2 className="text-lg font-semibold">Nur Hayat Yavuz</h2>
            <p className="text-sm text-muted-foreground">Bilgisayar Mühendisi</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarSeparator />

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menü</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={isActive("/")}>
                  <Link href="/">
                    <Home />
                    <span>Ana Sayfa</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={isActive("/hakkimda")}>
                  <Link href="/hakkimda">
                    <User />
                    <span>Hakkımda</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={isActive("/yetenekler")}>
                  <Link href="/yetenekler">
                    <Code />
                    <span>Yetenekler</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={isActive("/projeler")}>
                  <Link href="/projeler">
                    <FileCode />
                    <span>Projeler</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={isActive("/blog")}>
                  <Link href="/blog">
                    <BookOpen />
                    <span>Blog</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={isActive("/iletisim")}>
                  <Link href="/iletisim">
                    <Mail />
                    <span>İletişim</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator />

        <SidebarGroup>
          <SidebarGroupLabel>İletişim</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <a href="tel:+905437600813">
                    <Phone />
                    <span>+90 543-760-0813</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <a href="mailto:ynurhayat324@gmail.com">
                    <Mail />
                    <span>ynurhayat324@gmail.com</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <a href="https://github.com/nurhayatyavuz" target="_blank" rel="noopener noreferrer">
                    <Github />
                    <span>GitHub</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <a href="https://linkedin.com/in/nur-hayat-yavuz" target="_blank" rel="noopener noreferrer">
                    <Linkedin />
                    <span>LinkedIn</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground">© 2024 Nur Hayat Yavuz</p>
          <ModeToggle />
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
